<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/** 
* This is the class Admin for the Admin functnality.
*/ 
class Admin extends CI_Controller
{
	/** 
	* This is the Constructor of this Class in this we load libraries and Models.
	* @see model/Admin_model, model/Reports_model for Models  
	*/
    public function __construct()
    {
        parent::__construct();
        $this->load->library('encrypt');
        $this->load->library('encryption');
        $this->load->model('Admin_model');
        $this->load->model('Reports_model');
    }//end __construct

	/** 
	* This function is for signed in user with session redirection.
	*/
    public function index()
    {
        $this->load->library('encrypt');
        $admin_id = $this->session->userdata('admin_id');
        if ($admin_id) { //start if Statment for check admin_id isset or not 
            redirect('/admin/dashboard/');
        }//endif 
        if ($this->input->server('REQUEST_METHOD') === 'POST') { //start if statment for Check REQUEST_METHOD is POST
            //set Rules for the Validition of Username and Password
			$this->form_validation->set_rules(array(
                array(
                    'field' => 'username',
                    'rules' => 'trim|required|max_length[50]'
                ),
                array(
                    'field' => 'password',
                    'rules' => 'trim|required|max_length[50]'
                )
            ));
            if ($this->form_validation->run() === TRUE) {//start if statment for Check Posted Record is Valid
				//Get Posted Username and its Status 
                $admin_user = $this->Admin_model->authenticate_user(array('user_name' => $this->input->post('username', TRUE), 'is_active' => STATUS_ACTIVE));
				
                if (isset($admin_user->admin_id) && $this->encrypt->decode($admin_user->password) === $this->input->post('password', TRUE)) {//start if statment for Check admin_id is set or not and also match password
                    $this->session->set_userdata(array('admin_id' => $admin_user->admin_id));
                    // Redirect signed in user with session redirect
                    if ($redirect = $this->session->userdata('sign_in_redirect')) {
                        $this->session->unset_userdata('sign_in_redirect');
                        redirect($redirect);
                    }
                    redirect('admin/dashboard');
                } else {//start else statment
                    $data['error_msg'] = "Invalid username or password.";
                }//end else statment
            } else {//start else statment
                $data['error_msg'] = "Invalid username or password.";
            }//end else statment
        }//end if statment
		
        // Load sign in view
        $this->load->view('admin/login', isset($data) ? $data : '');
    }//end index function
	
	/** 
	* This function is for signed out user with destoring Session.
	*/
    public function logout()
    {
		// check admin is not logged in
        if (!is_admin_loggedin()) {
            redirect('admin');
        }//end if statment
		//destory Session and Redirect to admin
        $this->session->sess_destroy();
        redirect('admin');
    }// end logout function
	
	/** 
	*This function is for Changing password.
	*/
    public function change_pass()
    {
		// check admin is not logged in
        is_admin_loggedin('admin/change_pass');
		//Check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
			//set rules for new password
            $this->form_validation->set_rules(array(
                array(
                    'field' => 'old_pass',
                    'rules' => 'trim|required'
                ),
                array(
                    'field' => 'new_pass',
                    'rules' => 'trim|required'
                ),
                array(
                    'field' => 'conf_pass',
                    'rules' => 'trim|required|matches[new_pass]'
                )
            ));
            // Run form validation
            if ($this->form_validation->run() === TRUE) {
                $admin_user = $this->Admin_model->authenticate_user(array('admin_id' => $this->session->userdata('admin_id')));
				//check adminID is Set and match old password.
                if (isset($admin_user->admin_id) && $this->encrypt->decode($admin_user->password) === $this->input->post('old_pass', TRUE)) {
                    $this->Admin_model->update($this->session->userdata('admin_id'), array('password' => $this->encrypt->encode($this->input->post('new_pass', TRUE))));
                    $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Password has been changed!');
                    redirect('admin/admin/change_pass');
                } else {// else statment if incorrect Field
                    $data['error_msg'] = "Incorrect Field.";
                }//end if statment
            } else { // else statment id password is Incorrect
                $data['error_msg'] = "Incorrect password.";
            }//end if statment
        }//end if Statment
        $this->load->view('admin/change_pass', isset($data) ? $data : NULL);
    }//end change_pass function

	/** 
	*This function is for dashboard page functionality .
	*/
    public function dashboard()
    {
		// check admin is not logged in
        is_admin_loggedin('admin/dashboard');
		//get roles of POWERBI form Admin Model
		$data['powerBI'] = $this->Admin_model->get_powerBI_roles();
		//get List of all Activate Vendor form Report Model
		$data['vendor'] = $this->Reports_model->get_all_vendors();
		//load dashboard View.
        $this->load->view('admin/dashboard', isset($data) ? $data : NULL);
    }// end Dashboad function
	
	/** 
	*This function is for Vendor Information page.
	*/
	public function vendorInfo()
    {
		// check admin is not logged in
        is_admin_loggedin('admin/admin/vendorInfo');
		//get List of all Vendor form Report Model
		$data['vendor'] = $this->Reports_model->get_vendors_list();
		//load Vendor Information View.
        $this->load->view('admin/view_vendor', isset($data) ? $data : NULL);
    }//end vendorInfo function

    /** 
	*This function is for Adding new vendor to system.
	*/
    public function vendor()
    {
		// check admin is not logged in
        is_admin_loggedin('admin/vendor');
		//get List of all Vendor form Report Model
		$data['vendor'] = $this->Reports_model->get_vendors_list();
		//check REQUEST_METHOD is POST or NOt
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
			//get Values from POST Variable
            $fname = $this->input->post('fname', true);
            $lname = $this->input->post('lname', true);
            $email = $this->input->post('email', true);
            $vendor = $this->input->post('vendor', true);
            $domain = $this->input->post('domain', true);
            $tier = $this->input->post('tier', true);
			//get Vendor Existance
            $CheckVendorExistResponse = $this->Admin_model->checkVendorExist($vendor, $domain);
            // Check Vendor is Exist or NOT
            if ($CheckVendorExistResponse) {
                $addResponse = $this->Admin_model->AddVendorRecord($fname,$lname,$email,$vendor, $domain, $tier);
				//check responce of Adding new Vendor
                if ($addResponse) {
                    $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Vendor added successfully.');
                } else {//when vendor is not added
                    $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Fail to Add this Vendor!');
                }//end else statment
            } else {// when vendor already exist
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> This vendor Already exist.');
            }//end else statment
            redirect('admin/admin/vendorInfo');
        }//end if statment
        $this->load->view('admin/view_vendor', isset($data) ? $data : NULL);
    }//end vendor function
	
	/** 
	*This function is for Updating vendor information.
	*/
    public function setVendor()
    {
		// check admin is not logged in
        is_admin_loggedin('admin/setVendor');
		// get List of all vendors
		$data['vendor'] = $this->Reports_model->get_vendors_list();
		// check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
			// get values from the post variable
            $vendor_id = $this->input->post('update_vendor_id', true);
            $vendor_name = $this->input->post('update_vendor_name', true);
            $vendor_domain = $this->input->post('update_vendor_domain', true);
            $vendor_tier = $this->input->post('update_vendor_tier', true);
			//get Vendor Existence
            $CheckVendorExistResponse = $this->Admin_model->checkVendorExist($vendor_name, $vendor_domain,$vendor_id);
            // Check Vendor is Exist or NOT
            if ($CheckVendorExistResponse) {
				// get responce from Updating Vendor Record
                $addResponse = $this->Admin_model->UpdateVendorRecord($vendor_id,$vendor_name,$vendor_domain,$vendor_tier);
				// check responce for editing Vendor
                if ($addResponse) {
                    $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Vendor Record Saved Successfully');
                } else {//When Vendor is not Updated
                    $this->session->set_flashdata('success_msg', '<strong>Success!</strong>  No changes made, Record Saved!');
                }//end if statment
            } else {//when this vendor already exist
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> This vendor already exist.');
            }//end if statment
			//get upadted List of all vendors
			$data['vendor'] = $this->Reports_model->get_vendors_list();
			//redirect to vendorInfo
			redirect('admin/admin/vendorInfo');
        }
		//load view_vendor page
        $this->load->view('admin/view_vendor', isset($data) ? $data : NULL);
    }//end setVendor function
	
	/** 
	*This function is for Inactivate vendor information.
	*/
    public function inactivateVendor()
    {
		// check admin is not logged in
        is_admin_loggedin('admin/inactivateVendor');
		// get List of all vendors
		$data['vendor'] = $this->Reports_model->get_vendors_list();
        // check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
			// get values from the post variable
            $vendor_id = $this->input->post('inactivate_vendor_id', true);
			//  get responce of Deleting Vendor Record
			$addResponse = $this->Admin_model->InactiveVendorRecord($vendor_id);
			// check responce for Vendor Deletion
			if ($addResponse) {
				$this->session->set_flashdata('success_msg', '<strong>Success!</strong> Vendor Inactivated Successfully.');
			} else {// when faild to delete
				$this->session->set_flashdata('error_msg', '<strong>Error!</strong> Fail to Inactivate this Vendor!');
			}//end if statment
			//get upadted List of all vendors
			$data['vendor'] = $this->Reports_model->get_vendors_list();
			//redirect to vendorInfo
			redirect('admin/admin/vendorInfo');
        }
		//load view_vendor page
        $this->load->view('admin/view_vendor', isset($data) ? $data : NULL);
    }//end inactivateVendor function
	
	/** 
	*This function is for Activate vendor information.
	*/
    public function activateVendor()
    {
		// check admin is not logged in
        is_admin_loggedin('admin/activateVendor');
		// get List of all vendors
		$data['vendor'] = $this->Reports_model->get_vendors_list();
        // check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            // get values from the post variable
            $vendor_id = $this->input->post('activate_vendors_id', true);
			//  get responce of Activating Vendor Record
			$addResponse = $this->Admin_model->ActivateVendor($vendor_id);
			// check responce for Vendor Activation
			if ($addResponse) {
				$this->session->set_flashdata('success_msg', '<strong>Success!</strong> Vendor Activated Successfully.');
			} else {//when fail to Activate Vendor
				$this->session->set_flashdata('error_msg', '<strong>Error!</strong> Fail to Activate this Vendor!');
			}//end if statment
			//get upadted List of all vendors
			$data['vendor'] = $this->Reports_model->get_vendors_list();
			//redirect to vendorInfo
			redirect('admin/admin/vendorInfo');
        }
        //load view_vendor page
        $this->load->view('admin/view_vendor', isset($data) ? $data : NULL);
    }//end activateVendor function
	
}//end Admin Class