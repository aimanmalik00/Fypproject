<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-24 06:25:02 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-24 12:13:37 --> Severity: Warning --> Missing argument 1 for Admin_model::get_vendor_name(), called in C:\xampp\htdocs\dev.tanabi\application\controllers\admin\Cron.php on line 42 and defined C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 165
ERROR - 2020-02-24 12:13:38 --> Severity: Notice --> Undefined variable: vendor_id C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 169
ERROR - 2020-02-24 12:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 172
ERROR - 2020-02-24 12:16:10 --> Severity: Parsing Error --> syntax error, unexpected '$result' (T_VARIABLE) C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 173
