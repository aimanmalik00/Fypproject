<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-13 05:52:25 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
