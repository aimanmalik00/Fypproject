<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-28 22:49:28 --> 404 Page Not Found: Wp_loginphp/index
