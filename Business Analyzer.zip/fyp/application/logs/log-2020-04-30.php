<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-30 10:56:34 --> 404 Page Not Found: Wp_loginphp/index
