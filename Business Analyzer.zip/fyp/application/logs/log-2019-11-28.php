<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-28 10:47:36 --> Severity: Notice --> Undefined variable: delete_executivedashboard C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Reports.php 2017
ERROR - 2019-11-28 10:47:55 --> Severity: Notice --> Undefined variable: delete_executivedashboard C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Reports.php 2017
ERROR - 2019-11-28 10:48:03 --> Severity: Notice --> Undefined variable: delete_executivedashboard C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Reports.php 2017
ERROR - 2019-11-28 10:48:26 --> Severity: Notice --> Undefined variable: delete_executivedashboard C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Reports.php 2017
ERROR - 2019-11-28 11:08:53 --> Severity: Notice --> Undefined variable: delete_executivedashboard C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Reports.php 2017
ERROR - 2019-11-28 11:09:13 --> Severity: Notice --> Undefined variable: delete_executivedashboard C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Reports.php 2017
