<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-05 04:24:21 --> 404 Page Not Found: /index
