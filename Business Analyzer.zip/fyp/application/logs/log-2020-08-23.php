<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-23 16:01:36 --> Query error: Table 'fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-08-23 16:07:54 --> Query error: Table 'fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-08-23 16:37:56 --> Query error: Table 'fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-08-23 16:38:07 --> Query error: Table 'fyp.tbl_stage_tanabi_dropship' doesn't exist - Invalid query: SELECT *
FROM `tbl_stage_tanabi_dropship`
WHERE `fk_vendor_id` IS NULL
