<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-25 02:10:19 --> 404 Page Not Found: Adminer/index.php
ERROR - 2020-05-25 14:21:11 --> 404 Page Not Found: Wp_loginphp/index
