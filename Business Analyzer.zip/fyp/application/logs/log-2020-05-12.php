<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-12 01:18:06 --> 404 Page Not Found: /index
