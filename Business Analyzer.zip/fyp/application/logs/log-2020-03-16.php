<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-16 12:38:46 --> 404 Page Not Found: Wp_loginphp/index
