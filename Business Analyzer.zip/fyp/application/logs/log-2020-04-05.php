<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-05 18:22:07 --> 404 Page Not Found: /index
