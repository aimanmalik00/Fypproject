<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-18 08:30:09 --> 404 Page Not Found: Cron/upload_ftp_reports
ERROR - 2020-02-18 08:30:32 --> Severity: Error --> Call to a member function row() on array C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 170
ERROR - 2020-02-18 08:31:49 --> Severity: Error --> Call to a member function row() on array C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 170
ERROR - 2020-02-18 08:31:50 --> Severity: Error --> Call to a member function row() on array C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 170
ERROR - 2020-02-18 08:31:51 --> Severity: Error --> Call to a member function row() on array C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 170
ERROR - 2020-02-18 08:31:51 --> Severity: Error --> Call to a member function row() on array C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 170
ERROR - 2020-02-18 08:31:51 --> Severity: Error --> Call to a member function row() on array C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 170
ERROR - 2020-02-18 08:31:51 --> Severity: Error --> Call to a member function row() on array C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 170
ERROR - 2020-02-18 08:33:06 --> Severity: Notice --> Undefined index: vendor_name C:\xampp\htdocs\dev.tanabi\application\controllers\admin\Cron.php 42
ERROR - 2020-02-18 08:34:22 --> Severity: Error --> Call to a member function row() on array C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 170
ERROR - 2020-02-18 08:35:48 --> Severity: Error --> Call to a member function row() on array C:\xampp\htdocs\dev.tanabi\application\models\Admin_model.php 170
ERROR - 2020-02-18 08:37:05 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\dev.tanabi\application\controllers\admin\Cron.php 42
ERROR - 2020-02-18 08:37:07 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\dev.tanabi\application\controllers\admin\Cron.php 42
