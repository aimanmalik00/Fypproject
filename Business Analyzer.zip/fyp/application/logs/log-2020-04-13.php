<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-13 09:15:05 --> 404 Page Not Found: Wp_loginphp/index
