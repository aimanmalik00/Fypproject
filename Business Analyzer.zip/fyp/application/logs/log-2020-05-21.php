<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-21 19:24:45 --> 404 Page Not Found: Wp_loginphp/index
