<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-22 08:42:53 --> 404 Page Not Found: Wp_loginphp/index
