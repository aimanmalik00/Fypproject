<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-11 01:58:03 --> 404 Page Not Found: /index
ERROR - 2020-05-11 01:58:03 --> 404 Page Not Found: /index
ERROR - 2020-05-11 01:58:03 --> 404 Page Not Found: /index
ERROR - 2020-05-11 14:32:22 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-05-11 16:23:14 --> 404 Page Not Found: Wp_loginphp/index
