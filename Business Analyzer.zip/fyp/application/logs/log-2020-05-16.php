<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-16 04:23:07 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-05-16 06:27:15 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-05-16 20:20:08 --> 404 Page Not Found: Adminer/index.php
