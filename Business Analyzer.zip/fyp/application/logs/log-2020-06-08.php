<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-08 05:44:16 --> 404 Page Not Found: Wp_loginphp/index
