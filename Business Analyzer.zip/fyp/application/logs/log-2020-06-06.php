<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-06 11:10:45 --> 404 Page Not Found: /index
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-06 11:10:45 --> 404 Page Not Found: /index
