<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-09 08:25:47 --> 404 Page Not Found: /index
