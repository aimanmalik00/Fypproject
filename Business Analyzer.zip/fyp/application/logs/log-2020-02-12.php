<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-12 10:55:05 --> Severity: Notice --> Undefined index: CI_ENV C:\xampp\htdocs\dev.tanabi\application\controllers\admin\Cron.php 46
ERROR - 2020-02-12 10:55:05 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 10:55:18 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 10:56:53 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 10:56:57 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 10:59:29 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 11:00:13 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 11:00:41 --> Severity: Warning --> ftp_login(): Not logged in - Secure authentication required C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2352
ERROR - 2020-02-12 11:00:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dev.tanabi\application\controllers\admin\Cron.php 53
ERROR - 2020-02-12 11:00:59 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 11:05:57 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 11:06:35 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 11:07:02 --> Severity: Notice --> Undefined index: CI_ENV C:\xampp\htdocs\dev.tanabi\application\controllers\admin\Cron.php 46
ERROR - 2020-02-12 11:07:02 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 11:17:28 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 11:22:40 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
ERROR - 2020-02-12 12:37:15 --> Severity: Error --> Call to undefined function ftp_ssl_connect() C:\xampp\htdocs\dev.tanabi\application\helpers\general_helper.php 2350
