<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-11 20:13:35 --> 404 Page Not Found: /index
ERROR - 2020-04-11 20:13:35 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-04-11 20:13:35 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2020-04-11 20:13:35 --> 404 Page Not Found: Blogs/wp_login.php
ERROR - 2020-04-11 20:13:35 --> 404 Page Not Found: Home/wp_login.php
ERROR - 2020-04-11 20:13:35 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2020-04-11 20:13:35 --> 404 Page Not Found: Press/wp_login.php
ERROR - 2020-04-11 20:13:35 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: Wpmu/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: Web/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: New/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: News/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: Site/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: Sites/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: Sitio/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: En/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: Old/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: Info/wp_login.php
ERROR - 2020-04-11 20:13:36 --> 404 Page Not Found: Demo/wp_login.php
ERROR - 2020-04-11 20:13:37 --> 404 Page Not Found: Portal/wp_login.php
ERROR - 2020-04-11 20:13:37 --> 404 Page Not Found: English/wp_login.php
