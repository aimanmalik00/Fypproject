<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-27 05:04:36 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
