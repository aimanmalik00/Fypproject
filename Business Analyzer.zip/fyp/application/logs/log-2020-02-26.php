<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-26 18:14:27 --> 404 Page Not Found: /index
ERROR - 2020-02-26 18:14:36 --> 404 Page Not Found: /index
ERROR - 2020-02-26 18:14:41 --> 404 Page Not Found: Index1php/index
ERROR - 2020-02-26 18:36:18 --> 404 Page Not Found: /index
ERROR - 2020-02-26 18:38:43 --> 404 Page Not Found: /index
ERROR - 2020-02-26 18:39:18 --> 404 Page Not Found: /index
ERROR - 2020-02-26 18:39:51 --> 404 Page Not Found: /index
ERROR - 2020-02-26 18:40:34 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:40:44 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:40:54 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:41:20 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:41:45 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:41:51 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:42:15 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:42:22 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:43:15 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:44:44 --> 404 Page Not Found: /index
ERROR - 2020-02-26 18:49:12 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:49:47 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:49:59 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:50:11 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:53:36 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 18:53:57 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
ERROR - 2020-02-26 19:10:22 --> Severity: Warning --> base64_decode() has been disabled for security reasons /home/romanamin/etl.romanamin.com/system/libraries/Encrypt.php 183
