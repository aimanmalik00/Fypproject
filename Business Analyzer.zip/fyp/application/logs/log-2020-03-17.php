<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-17 14:05:36 --> 404 Page Not Found: Wp_loginphp/index
