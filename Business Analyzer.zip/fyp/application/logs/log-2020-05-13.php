<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-13 02:43:01 --> 404 Page Not Found: /index
ERROR - 2020-05-13 02:43:02 --> 404 Page Not Found: /index
ERROR - 2020-05-13 03:10:17 --> 404 Page Not Found: /index
