<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-25 10:43:08 --> Query error: Table 'fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-08-25 14:17:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Validation_Model C:\xampp\htdocs\fyp\system\core\Loader.php 344
ERROR - 2020-08-25 14:22:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Validation_Model C:\xampp\htdocs\fyp\system\core\Loader.php 344
ERROR - 2020-08-25 14:22:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Validation_Model C:\xampp\htdocs\fyp\system\core\Loader.php 344
ERROR - 2020-08-25 14:24:24 --> Severity: error --> Exception: C:\xampp\htdocs\fyp\application\models/Reports_model.php exists, but doesn't declare class Reports_model C:\xampp\htdocs\fyp\system\core\Loader.php 336
ERROR - 2020-08-25 14:27:54 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:27:54 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:27:54 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:27:54 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:27:54 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:27:54 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:27:54 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:27:54 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:27:54 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:27:54 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:27:55 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:27:56 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:27:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\fyp\system\core\Exceptions.php:272) C:\xampp\htdocs\fyp\system\helpers\url_helper.php 564
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:29:31 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:29:32 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:29:33 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:29:34 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:29:34 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:29:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\fyp\system\core\Exceptions.php:272) C:\xampp\htdocs\fyp\system\helpers\url_helper.php 564
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:30:56 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:30:57 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 14:30:58 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 14:30:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\fyp\system\core\Exceptions.php:272) C:\xampp\htdocs\fyp\system\helpers\url_helper.php 564
ERROR - 2020-08-25 14:55:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 508
ERROR - 2020-08-25 14:55:56 --> Severity: Warning --> Illegal string offset 'asin' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 517
ERROR - 2020-08-25 14:55:56 --> Severity: Warning --> Illegal string offset 'product_title' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 519
ERROR - 2020-08-25 14:55:56 --> Severity: Warning --> Illegal string offset 'shipped_units' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 538
ERROR - 2020-08-25 14:55:56 --> Severity: Warning --> Illegal string offset 'shipped_units_last_year' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 541
ERROR - 2020-08-25 14:55:56 --> Severity: Warning --> Illegal string offset 'shipped_units_last_year' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 542
ERROR - 2020-08-25 14:55:56 --> Severity: Warning --> Illegal string offset 'customer_returns' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 545
ERROR - 2020-08-25 14:55:56 --> Severity: Warning --> Illegal string offset 'free_replacements' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 546
ERROR - 2020-08-25 14:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\fyp\system\core\Exceptions.php:272) C:\xampp\htdocs\fyp\system\helpers\url_helper.php 564
ERROR - 2020-08-25 15:29:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 15:29:08 --> Unable to connect to the database
ERROR - 2020-08-25 15:29:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 15:29:44 --> Unable to connect to the database
ERROR - 2020-08-25 15:29:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 15:29:52 --> Unable to connect to the database
ERROR - 2020-08-25 16:43:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 16:43:15 --> Unable to connect to the database
ERROR - 2020-08-25 16:43:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 16:43:37 --> Unable to connect to the database
ERROR - 2020-08-25 16:46:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 16:46:51 --> Unable to connect to the database
ERROR - 2020-08-25 17:14:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 17:14:49 --> Unable to connect to the database
ERROR - 2020-08-25 17:14:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 17:14:49 --> Unable to connect to the database
ERROR - 2020-08-25 17:15:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 17:15:04 --> Unable to connect to the database
ERROR - 2020-08-25 17:15:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 17:15:06 --> Unable to connect to the database
ERROR - 2020-08-25 19:30:57 --> Severity: Error --> Call to undefined method Reports_model::get_all_dropship_count() C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 2932
ERROR - 2020-08-25 19:59:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'fyp' C:\xampp\htdocs\fyp\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-08-25 19:59:34 --> Unable to connect to the database
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 20:08:27 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: asin C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 403
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: product_title C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 404
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 405
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 409
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 410
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 413
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 414
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 415
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs_percentage_total C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 416
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_cogs_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 418
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 419
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 422
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: shipped_units_last_year C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 423
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: customer_returns C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 426
ERROR - 2020-08-25 20:08:28 --> Severity: Notice --> Undefined index: free_replacements C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 427
ERROR - 2020-08-25 20:08:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\fyp\system\core\Exceptions.php:272) C:\xampp\htdocs\fyp\system\helpers\url_helper.php 564
ERROR - 2020-08-25 20:09:58 --> Severity: Warning --> Illegal string offset 'asin' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 679
ERROR - 2020-08-25 20:09:58 --> Severity: Warning --> Illegal string offset 'customer_returns' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 700
ERROR - 2020-08-25 20:09:58 --> Severity: Warning --> Illegal string offset 'free_replacements' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 701
ERROR - 2020-08-25 20:32:22 --> Severity: Warning --> Illegal string offset 'asin' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 679
ERROR - 2020-08-25 20:32:22 --> Severity: Warning --> Illegal string offset 'customer_returns' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 700
ERROR - 2020-08-25 20:32:22 --> Severity: Warning --> Illegal string offset 'free_replacements' C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 701
ERROR - 2020-08-25 20:35:44 --> Severity: Error --> Call to undefined method Reports_model::get_traffic_last_entries() C:\xampp\htdocs\fyp\application\controllers\admin\Reports.php 1103
