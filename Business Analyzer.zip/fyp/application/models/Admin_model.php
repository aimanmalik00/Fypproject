<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
*This Class is for Admin Model for All Admin Database operations
*/
class Admin_model extends CI_Model
{
    private $table_name = "tbl_admin";
    private $tbl_purchaseorders_vendors = "tbl_purchaseorders_vendors";
    private $tbl_powerbi_roles = "tbl_powerbi_roles";
	/*
	*This function is for authenticate Admin Information
	*@param data
	*/
    public function authenticate_user($data)
    {
        return $this->db->get_where($this->table_name, $data)->row();
    }//end function authenticate_user($data)

	/*
	*This function is for Updating Admin Information
	*@param user_id
	*@param data
	*@return mixed
	*/
    function update($user_id, $data)
    {
        $this->db->where('admin_id', $user_id);
        return $this->db->update($this->table_name, $data);
    }//end function update
	
	/**
	*this function is getting list of PowerBI roles
	* @return mixed
	*/
    function get_powerBI_roles()
    {
        $this->db->select();
        $this->db->from('tbl_powerbi_roles');
        return $this->db->get()->result();
    }//end function get_powerBI_roles()

    /**
     * This function is used to Check Vendor is Exist or NOT
     * @param $vendor_name
	 * @param $domain
	 * @param $vendor_id
     * @return bool
     */
	public function checkVendorExist($vendor_name, $domain,$vendor_id = 0 )
	{
		$this->db->where('vendor_name', $vendor_name);
		$this->db->where('domain', $domain);
		$this->db->where_not_in('vendor_id', $vendor_id);
		$this->db->from($this->tbl_purchaseorders_vendors);
		if ($this->db->count_all_results() == 0) {
			return true;
		}//end if statment
		return false;
	}//end function checkVendorExist


    /**
     * This function is used to ADD new Vendor Code into DB
     * @param $fname
     * @param $lname
     * @param $email
     * @param $vendor
     * @param $domain
     * @param $tier
     * @return bool
     */
    public function AddVendorRecord($fname, $lname, $email, $vendor, $domain, $tier)
    {
		//create Data Array
        $data = array(
            'vendor_name' => $vendor,
            'domain' => $domain,
            'tier' => $tier,
            'created_date' => date('Y-m-d h:i:s'),
            'vendor_status' => 1
        );

        $this->db->insert($this->tbl_purchaseorders_vendors, $data);
        if ($this->db->affected_rows() > 0) {
            $insertedID = $this->db->insert_id();
            $dataPBI = array(
                'first_name' => $fname,
                'last_name' => $lname,
                'email' => $email,
                'fk_vendor_id' => $insertedID,
                'is_manager' => 0
            );
            $this->db->insert($this->tbl_powerbi_roles, $dataPBI);
            return true;
        }//end if statment
        return false;
    }//end function AddVendorRecord
	
	 /**
     * This function is used to update Venodr in DB
     * @param $id
     * @param $vendor
     * @param $domain
     * @param $tier
	 * @return bool
     */
    public function UpdateVendorRecord($id, $vendor, $domain, $tier)
    {
		//create Data Array
        $data = array(
            'vendor_name' => $vendor,
            'domain' => $domain,
            'tier' => $tier,
        );
		$this->db->where('vendor_id',$id);
        $this->db->update($this->tbl_purchaseorders_vendors, $data);
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function UpdateVendorRecord
	
	/**
     * This function is used to inactive Venodr in DB
     * @param $id
	 * @return bool
     */
    public function InactiveVendorRecord($id)
    {
		//create Data Array
        $data = array(
            'vendor_status' => 0
        );
		$this->db->where('vendor_id',$id);
        $this->db->update($this->tbl_purchaseorders_vendors, $data);
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function InactiveVendorRecord
	
	/**
     * This function is used to Activate Venodr in DB
     * @param $id
	 * @return bool
     */
    public function ActivateVendor($id)
    {
		//create Data Array
        $data = array(
            'vendor_status' => 1
        );
		$this->db->where('vendor_id',$id);
        $this->db->update($this->tbl_purchaseorders_vendors, $data);
        if ($this->db->affected_rows() > 0) {
            return true;
        }//enf if statment
        return false;
    }//en function ActivateVendor

    /**
     *this function is getting list of PowerBI roles
     * @return mixed
     */
    function get_vendor_name($vendor_id)
    {
        $this->db->select('vendor_name');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->where('vendor_id',$vendor_id);
        $query = $this->db->get();
        $return = $query->result();
        if(sizeof($return) == 1){
            return $return[0]->vendor_name;
        }
        return "";
    }//end function get_powerBI_roles()

	
}//end class Admin_model