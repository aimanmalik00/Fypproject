<?php $this->load->view('admin/includes/header'); ?>
<?php $this->load->view('admin/includes/header_files.php')?>
<?php echo isset($success_msg)?success_msg:""; ?>
    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
      <?php $this->load->view('admin/includes/header_nav.php');?>
      <div class="alert alert-danger display-hide">
          <button class="close" data-close="alert"></button> You have some form errors. Please check below. </div>
      <div class="portlet-body">
        <div class="page-container">
          <?php $this->load->view('admin/includes/side_bar.php');?>
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <?php echo form_open_multipart(current_url(),array('name'=>'settings','id'=>'settings','method'=>'post','role'=>'form', 'class' =>'form-horizontal' )); ?>
                        <h1>Edit Setting </h1>
                    <?php include(APPPATH.'views/admin/_messages.php') ?>
                    <div class="form-body">
                            <div class="alert alert-danger display-hide">
                                <button class="close" data-close="alert"></button> You have some form errors. Please check below. </div>
                            <div class="alert alert-success display-hide">
                                <button class="close" data-close="alert"></button> Your form validation is successful! </div>
                            <div class="form-group">
                                <label class="control-label col-md-3">Name
                                    <span class="required"> * </span>
                                </label>
                                <div class="col-md-4">
                                    <input type="text" name="title" data-required="1" class="form-control" value="<?php echo $settings_data[0]->name; ?>" readonly/> </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3">Value
                                </label>
                                <div class="col-md-4">
                                    <textarea  type="text" name="setting_value" class="form-control"><?php echo $settings_data[0]->value; ?></textarea> </div>
                            </div>
                              <div class="form-group">
                                <label class="control-label col-md-3">Description
                                </label>
                                <div class="col-md-4">
                                    <textarea  type="text" name="setting_descp" maxlength="300" class="form-control"><?php echo $settings_data[0]->description; ?></textarea> </div>
                            </div>
                            

                        </div>

                            <div class="form-actions">
                                <div class="row">
                                <div class="col-md-offset-3 col-md-9">
                                    <button id="btn_submit" type="submit" class="btn green">Submit</button>
                                </div>
                            </div>
                        </div>

                        <?php echo form_close(); ?>  
                </div>
               
                <!-- END CONTENT BODY -->
            </div>
               
                
                

        <!-- END CONTAINER -->
        <!-- BEGIN FOOTER -->
        <?php $this->load->view('admin/includes/footer_files')?>
        <?php $this->load->view('admin/includes/footer'); ?>
  

<script>
var FormValidation = function () {

    // basic validation
    var handleValidation1 = function() {
        // for more info visit the official plugin documentation: 
            // http://docs.jquery.com/Plugins/Validation

            var form1 = $('#settings');
            var error1 = $('.alert-danger', form1);
            var success1 = $('.alert-success', form1);

            form1.validate({
                errorElement: 'span', //default input error message container
                errorClass: 'help-block help-block-error', // default input error message class
                focusInvalid: false, // do not focus the last invalid input
                ignore: "",  // validate all fields including form hidden input
                messages: {
                    select_multi: {
                        maxlength: jQuery.validator.format("Max {0} items allowed for selection"),
                        minlength: jQuery.validator.format("At least {0} items must be selected")
                    }
                },
                rules: {
                    setting_value: {
                        required: true
                    }
                },

                invalidHandler: function (event, validator) { //display error alert on form submit              
                    success1.hide();
                    error1.show();
                    App.scrollTo(error1, -200);
                },

                highlight: function (element) { // hightlight error inputs
                    $(element)
                        .closest('.form-group').addClass('has-error'); // set error class to the control group
                },

                unhighlight: function (element) { // revert the change done by hightlight
                    $(element)
                        .closest('.form-group').removeClass('has-error'); // set error class to the control group
                },

                success: function (label) {
                    label
                        .closest('.form-group').removeClass('has-error'); // set success class to the control group
                },

                submitHandler: function (form) {
                     $("#btn_submit").prop('disabled', true);
            		 form.submit();
                }
            });


    }
    return {
        //main function to initiate the module
        init: function () {

            handleValidation1();

        }

    };

}();

jQuery(document).ready(function() {
    FormValidation.init();
});


</script>


        <!-- END FOOTER -->
        <!--[if lt IE 9]>
<script src="../assets/global/plugins/respond.min.js"></script>
<script src="../assets/global/plugins/excanvas.min.js"></script>

<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
       
        <!-- END THEME LAYOUT SCRIPTS -->
        
    </body>

</html>      