<?php $this->load->view('admin/includes/header'); ?>
<?php $this->load->view('admin/includes/header_files.php')?>
  <link href="https://cdn.datatables.net/1.10.10/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
      <?php $this->load->view('admin/includes/header_nav.php');?>
      <div class="portlet-body">
        <div class="page-container">
          <?php $this->load->view('admin/includes/side_bar.php');?>
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
      <div class="page-content" style="min-height:1368px">
                    <!-- BEGIN PAGE HEADER-->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title">Settings
                    </h3>
                    <!-- END PAGE TITLE-->
                    <!-- END PAGE HEADER-->
      
          <div class="row">
               <div class="col-lg-12">
               			<div class="panel panel-default">
           						<div class="panel-heading"><span class="fl">Settings List</span> 
                                <div class="clearfix"></div></div>
          <!-- /.panel-heading -->
         <div class="panel-body">
     <?php include(APPPATH.'views/admin/_messages.php') ?>
          	<div class="table-responsive">
              <table class="table table-striped table-bordered table-hover" id="big_table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Value</th>
                    <th>Comments</th>
                    <th>Actions</th>
                  </tr>
                </thead>
              </table>
            </div>
            <!-- /.table-responsive --> 
            
          </div>
          <!-- /.panel-body --> 
        </div>
        <!-- /.panel --> 
      </div>
                            
                        </div>
                    </div>
                </div>
     
    <!-- END CONTENT BODY -->
</div>
               
                
                

        <!-- END CONTAINER -->
        <!-- BEGIN FOOTER -->
          <?php $this->load->view('admin/includes/footer_files')?>
        <?php $this->load->view('admin/includes/footer'); ?>
  
<script src="//cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>

 
<script>

$(document).ready(function() {
	make_datatable("big_table","/admin/settings/index","<?php echo $this->security->get_csrf_token_name(); ?>","<?php echo $this->security->get_csrf_hash(); ?>",0,0);
	
});

</script>

<script src="<?php echo base_url('/assets/Admin/js/script.js') ?>" type="text/javascript"></script>

        
    </body>

</html>      