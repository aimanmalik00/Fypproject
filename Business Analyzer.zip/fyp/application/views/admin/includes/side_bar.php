<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
		<?php 
				$controller_name = $this->router->class;
				$method_name = $this->router->method;
				$custom_link = $controller_name . '/' . $method_name;
		?>		
      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo base_url('admin/dashboard'); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class='fab fa-envelop'></i>
        </div>
        <div class="sidebar-brand-text mx-3">P/L Analyzer</div>
      </a>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item -->
      <li class="nav-item <?php if ($custom_link == "admin/dashboard") echo "active"; ?>">
        <a class="nav-link" href="<?php echo base_url('admin/dashboard');?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
	  
	  <!-- Nav Item 
      <li class="nav-item <?php if ($this->uri->segment(3) == "verify_executivedashboard") echo "active"; ?>">
        <a class="nav-link" href="<?php echo base_url('admin/reports/verify_executivedashboard');?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Executive Dashboard</span></a>
      </li>-->

	  <!-- Purchase Order Module - Nav Item -->
      <li class="nav-item <?=($this->uri->segment(3)=="purchaseorder" || $this->uri->segment(3)=="verify_po" || $this->uri->segment(3)=="po_dashboard")?'active':'';?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePO" aria-expanded="true" aria-controls="collapsePO">
          <i class="fa fa-shopping-cart"></i>
          <span>Purchase Order</span>
        </a>
        <div id="collapsePO" class="collapse <?=($this->uri->segment(3)=="purchaseorder" || $this->uri->segment(3)=="verify_po" || $this->uri->segment(3)=="po_dashboard")?'show':'';?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
			<a class="collapse-item <?=($this->uri->segment(3)=="po_dashboard")?'active':'';?>" href="<?php echo base_url('admin/reports/po_dashboard'); ?>">Dashboard</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="purchaseorder")?'active':'';?>" href="<?php echo base_url('admin/reports/purchaseorder'); ?>">Purchase Orders</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="verify_po")?'active':'';?>" href="<?php echo base_url('admin/reports/verify_po'); ?>">Verify PO</a>
          </div>
        </div>
      </li>

        <!-- DropShip Module - Nav Item -->
        <li class="nav-item <?=($this->uri->segment(3)=="monthly_dropship" || $this->uri->segment(3)=="verify_dropship" || $this->uri->segment(3)=="dropship_dashboard")?'active':'';?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseDashboard" aria-expanded="true" aria-controls="collapseDashboard">
                <i class="fas fa-fw fa-chart-area"></i>
                <span>Drop Ship</span>
            </a>
            <div id="collapseDashboard" class="collapse <?=($this->uri->segment(3)=="monthly_dropship" || $this->uri->segment(3)=="verify_dropship" || $this->uri->segment(3)=="dropship_dashboard")?'show':'';?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item <?=($this->uri->segment(3)=="dropship_dashboard")?'active':'';?>" href="<?php echo base_url('admin/reports/dropship_dashboard'); ?>">Dashboard</a>
                    <a class="collapse-item <?=($this->uri->segment(3)=="monthly_dropship")?'active':'';?>" href="<?php echo base_url('admin/reports/monthly_dropship'); ?>">Drop Ship</a>
                    <a class="collapse-item <?=($this->uri->segment(3)=="verify_dropship")?'active':'';?>" href="<?php echo base_url('admin/reports/verify_dropship'); ?>">Verify Dropship</a>
                </div>
            </div>
        </li>


        <!-- Sales Module - Nav Item -->
      <li class="nav-item <?=($this->uri->segment(3)=="sales_detailed" || $this->uri->segment(3)=="daily_sales"|| $this->uri->segment(3)=="weekly_sales_summary" || $this->uri->segment(3)=="monthly_sales_summary" || $this->uri->segment(3)=="verify_sales")?'active':'';?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSales" aria-expanded="true" aria-controls="collapseSales">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Sales</span>
        </a>
        <div id="collapseSales" class="collapse <?=($this->uri->segment(3)=="sales_detailed" || $this->uri->segment(3)=="daily_sales"|| $this->uri->segment(3)=="weekly_sales_summary" || $this->uri->segment(3)=="monthly_sales_summary" || $this->uri->segment(3)=="verify_sales" || $this->uri->segment(3)=="sales_dashboard")?'show':'';?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
			<a class="collapse-item <?=($this->uri->segment(3)=="sales_dashboard")?'active':'';?>" href="<?php echo base_url('admin/reports/sales_dashboard'); ?>">Dashboard</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="sales_detailed")?'active':'';?>" href="<?php echo base_url('admin/reports/sales_detailed'); ?>">Sales PTP</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="daily_sales")?'active':'';?>" href="<?php echo base_url('admin/reports/daily_sales'); ?>">Sales Daily</a>
			<a class="collapse-item <?=($this->uri->segment(3)=="weekly_sales_summary")?'active':'';?>" href="<?php echo base_url('admin/reports/weekly_sales_summary'); ?>">Sales Weekly</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="monthly_sales_summary")?'active':'';?>" href="<?php echo base_url('admin/reports/monthly_sales_summary'); ?>">Sales Monthly</a>
			<a class="collapse-item <?=($this->uri->segment(3)=="verify_sales")?'active':'';?>" href="<?php echo base_url('admin/reports/verify_sales'); ?>">Verify Sales</a>
          </div>
        </div>
      </li>
	  
	  
	   <!-- Inventory Module - Nav Item -->
      <li class="nav-item <?=($this->uri->segment(3)=="inventory_dashboard" || $this->uri->segment(3)=="daily_inventory"|| $this->uri->segment(3)=="weekly_inventory" || $this->uri->segment(3)=="monthly_inventory" || $this->uri->segment(3)=="verify_inventory")?'active':'';?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseInventory" aria-expanded="true" aria-controls="collapseInventory">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Inventory</span>
        </a>
        <div id="collapseInventory" class="collapse <?=($this->uri->segment(3)=="daily_inventory"|| $this->uri->segment(3)=="weekly_inventory" || $this->uri->segment(3)=="monthly_inventory" || $this->uri->segment(3)=="verify_inventory" || $this->uri->segment(3)=="inventory_dashboard")?'show':'';?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
			<a class="collapse-item <?=($this->uri->segment(3)=="inventory_dashboard")?'active':'';?>" href="<?php echo base_url('admin/reports/inventory_dashboard'); ?>">Dashboard</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="daily_inventory")?'active':'';?>" href="<?php echo base_url('admin/reports/daily_inventory'); ?>">Daily Inventory</a>
			<a class="collapse-item <?=($this->uri->segment(3)=="weekly_inventory")?'active':'';?>" href="<?php echo base_url('admin/reports/weekly_inventory'); ?>">Weekly Inventory</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="monthly_inventory")?'active':'';?>" href="<?php echo base_url('admin/reports/monthly_inventory'); ?>">Monthly Inventory</a>
			<a class="collapse-item <?=($this->uri->segment(3)=="verify_inventory")?'active':'';?>" href="<?php echo base_url('admin/reports/verify_inventory'); ?>">Verify Inventory</a>
          </div>
        </div>
      </li>
	  
	  
	  <!-- Traffic Module - Nav Item -->
      <li class="nav-item <?=($this->uri->segment(3)=="weekly_traffic" || $this->uri->segment(3)=="verify_traffic"  || $this->uri->segment(3)=="traffic_dashboard")?'active':'';?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTraffic" aria-expanded="true" aria-controls="collapseTraffic">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Traffic</span>
        </a>
        <div id="collapseTraffic" class="collapse <?=($this->uri->segment(3)=="weekly_traffic" || $this->uri->segment(3)=="verify_traffic"  || $this->uri->segment(3)=="traffic_dashboard" )?'show':'';?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
			<a class="collapse-item <?=($this->uri->segment(3)=="traffic_dashboard")?'active':'';?>" href="<?php echo base_url('admin/reports/traffic_dashboard'); ?>">Dashboard</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="weekly_traffic")?'active':'';?>" href="<?php echo base_url('admin/reports/weekly_traffic'); ?>">Weekly Traffic</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="verify_traffic")?'active':'';?>" href="<?php echo base_url('admin/reports/verify_traffic'); ?>">Verify Traffic</a>
          </div>
        </div>
      </li>
	  
	  <!-- Chargeback  Module - Nav Item -->
      <li class="nav-item <?=($this->uri->segment(3)=="chargeback_dashboard" ||$this->uri->segment(3)=="daily_chargeback" || $this->uri->segment(3)=="verify_chargeback")?'active':'';?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseChargeback " aria-expanded="true" aria-controls="collapseChargeback">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Chargeback </span>
        </a>
        <div id="collapseChargeback" class="collapse <?=($this->uri->segment(3)=="daily_chargeback" || $this->uri->segment(3)=="verify_chargeback"  || $this->uri->segment(3)=="chargeback_dashboard" )?'show':'';?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
			<a class="collapse-item <?=($this->uri->segment(3)=="chargeback_dashboard")?'active':'';?>" href="<?php echo base_url('admin/reports/chargeback_dashboard'); ?>">Dashboard</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="daily_chargeback")?'active':'';?>" href="<?php echo base_url('admin/reports/daily_chargeback'); ?>">Daily Chargeback </a>
            <a class="collapse-item <?=($this->uri->segment(3)=="verify_chargeback")?'active':'';?>" href="<?php echo base_url('admin/reports/verify_chargeback'); ?>">Verify Chargeback </a>
          </div>
        </div>
      </li>
	  
	  <!-- AMS  Module - Nav Item -->
      <li class="nav-item <?=($this->uri->segment(3)=="ams_dashboard" ||$this->uri->segment(3)=="ams_report" || $this->uri->segment(3)=="verify_ams")?'active':'';?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseAMS" aria-expanded="true" aria-controls="collapseAMS">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>AMS </span>
        </a>
        <div id="collapseAMS" class="collapse <?=($this->uri->segment(3)=="ams_report" || $this->uri->segment(3)=="verify_ams"  || $this->uri->segment(3)=="ams_dashboard" )?'show':'';?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
			<a class="collapse-item <?=($this->uri->segment(3)=="ams_dashboard")?'active':'';?>" href="<?php echo base_url('admin/reports/ams_dashboard'); ?>">Dashboard</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="ams_report")?'active':'';?>" href="<?php echo base_url('admin/reports/ams_report'); ?>">AMS Report </a>
            <a class="collapse-item <?=($this->uri->segment(3)=="verify_ams")?'active':'';?>" href="<?php echo base_url('admin/reports/verify_ams'); ?>">Verify AMS </a>
          </div>
        </div>
      </li>
	  
	  <!-- Forecast Module - Nav Item -->
      <li class="nav-item <?=($this->uri->segment(3)=="weekly_forecast" || $this->uri->segment(3)=="verify_forecast" || $this->uri->segment(3)=="forecast_dashboard")?'active':'';?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseForecast" aria-expanded="true" aria-controls="collapseForecast">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Forecast</span>
        </a>
        <div id="collapseForecast" class="collapse <?=($this->uri->segment(3)=="weekly_forecast" || $this->uri->segment(3)=="verify_forecast" || $this->uri->segment(3)=="forecast_dashboard")?'show':'';?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item <?=($this->uri->segment(3)=="forecast_dashboard")?'active':'';?>" href="<?php echo base_url('admin/reports/forecast_dashboard'); ?>">Dashboard</a>
			<a class="collapse-item <?=($this->uri->segment(3)=="weekly_forecast")?'active':'';?>" href="<?php echo base_url('admin/reports/weekly_forecast'); ?>">Weekly Forecast</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="verify_forecast")?'active':'';?>" href="<?php echo base_url('admin/reports/verify_forecast'); ?>">Verify Forecast</a>
          </div>
        </div>
      </li>
	  
	  <!-- Promotion  Module - Nav Item -->
      <li class="nav-item <?=($this->uri->segment(3)=="monthly_promotion" || $this->uri->segment(3)=="verify_promotion" || $this->uri->segment(3)=="promotion_dashboard")?'active':'';?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePromotion" aria-expanded="true" aria-controls="collapsePromotion">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Promotion Summary </span>
        </a>
        <div id="collapsePromotion" class="collapse <?=($this->uri->segment(3)=="monthly_promotion" || $this->uri->segment(3)=="verify_promotion" || $this->uri->segment(3)=="promotion_dashboard")?'show':'';?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item <?=($this->uri->segment(3)=="promotion_dashboard")?'active':'';?>" href="<?php echo base_url('admin/reports/promotion_dashboard'); ?>">Dashboard</a>
			<a class="collapse-item <?=($this->uri->segment(3)=="monthly_promotion")?'active':'';?>" href="<?php echo base_url('admin/reports/monthly_promotion'); ?>">Summary Report</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="verify_promotion")?'active':'';?>" href="<?php echo base_url('admin/reports/verify_promotion'); ?>">Verify Summary</a>
          </div>
        </div>
      </li>
	  
	  <!-- Brand Store Module - Nav Item -->
      <li class="nav-item <?=($this->uri->segment(3)=="weekly_brandstore" || $this->uri->segment(3)=="verify_brandstore" || $this->uri->segment(3)=="brandstore_dashboard")?'active':'';?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBrandStore" aria-expanded="true" aria-controls="collapseBrandStore">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Brand Store </span>
        </a>
        <div id="collapseBrandStore" class="collapse <?=($this->uri->segment(3)=="weekly_brandstore" || $this->uri->segment(3)=="verify_brandstore" || $this->uri->segment(3)=="brandstore_dashboard")?'show':'';?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item <?=($this->uri->segment(3)=="brandstore_dashboard")?'active':'';?>" href="<?php echo base_url('admin/reports/brandstore_dashboard'); ?>">Dashboard</a>
			<a class="collapse-item <?=($this->uri->segment(3)=="weekly_brandstore")?'active':'';?>" href="<?php echo base_url('admin/reports/weekly_brandstore'); ?>">Brand Store Report</a>
            <a class="collapse-item <?=($this->uri->segment(3)=="verify_brandstore")?'active':'';?>" href="<?php echo base_url('admin/reports/verify_brandstore'); ?>">Verify Brand Store</a>
          </div>
        </div>
      </li>

        
	  
	  

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->