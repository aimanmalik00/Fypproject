<?php $controller_name = $this->router->class;

$method_name = $this->router->method;
$custom_link = $controller_name . '/' . $method_name;
//echo $controller_name; die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('admin/includes/header'); ?>
	<?php $this->load->view('admin/includes/header_files');?>
</head>

<body id="page-top">
  <!-- Page Wrapper -->
  <div id="wrapper">
   <?php $this->load->view('admin/includes/side_bar');?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
        <!-- Topbar -->
			<?php $this->load->view('admin/includes/header_nav');?>
        <!-- End of Topbar -->
        <!-- Begin Page Content -->
		<div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800"> Upload Purchase Order</h1>
          
          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-12 col-lg-12">

              <!--  Form Area -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Select files from your computer</h6>
                </div>
                <div class="card-body">
				<?php echo form_open('admin/reports/ajaxPO', array('name' => 'popup', 'id' => 'popup', 'class' => 'form-horizontal', 'method' => 'post', 'enctype' => "multipart/form-data")); ?>
				<?php if ($this->session->flashdata('error_msg_open')) { ?>
					<div class="alert alert-danger"><?php echo $this->session->flashdata('error_msg_open'); ?></div>
				<?php } ?>
				<?php if ($this->session->flashdata('error_msg_close')) { ?>
					<div class="alert alert-danger"><?php echo $this->session->flashdata('error_msg_close'); ?></div>
				<?php } ?>
				<?php if ($this->session->flashdata('success_msg_open')) { ?>
					<div class="alert alert-success"><?php echo $this->session->flashdata('success_msg_open'); ?></div>
				<?php } ?>
				<?php if ($this->session->flashdata('success_msg_close')) { ?>
					<div class="alert alert-success"><?php echo $this->session->flashdata('success_msg_close'); ?></div>
				<?php } ?>
				<?php 
						$vendor_id=0;
						if ($this->session->flashdata('vendor_id')) { $vendor_id = $this->session->flashdata('vendor_msg'); }
						if(!isset($fk_vendor_id)){$fk_vendor_id=0;}
					?>
				<div class="form-group">
					<label class="control-label" for="sel1">Select Vendor:</label><select class="form-control" name="fk_vendor_id">
							 <?php foreach ($vendors as $row) : ?>
								<option value="<?php echo $row->vendor_id; ?>"
									<?=($row->vendor_id == $fk_vendor_id || $row->vendor_id == $vendor_id )?'Selected':''?>>
									<?php echo $row->vendor_name . ' ' . $row->domain; ?></option>
							<?php endforeach; ?>
						</select>
				</div>
				<div class="form-group">
					<label class="control-label" for="open_aggfile">OPEN AGG File</label>
					<div class="col-sm-12">
						<input type="file" class="custom-file-input" id="open_aggfile" name="open_aggfile" accept=".csv,.xlsx"  >
						<label class="custom-file-label" for="open_aggfile">Choose file</label>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label" for="open_nonaggfile">OPEN Non-AGG File</label>
					<div class="col-sm-12">
						<input type="file" class="custom-file-input" id="open_nonaggfile" name="open_nonaggfile" accept=".csv,.xlsx"  >
						<label class="custom-file-label" for="open_nonaggfile">Choose file</label>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label" for="close_aggfile">Close AGG File</label>
					<div class="col-sm-12">
						<input type="file" class="custom-file-input" id="close_aggfile" name="close_aggfile" accept=".csv,.xlsx"  >
						<label class="custom-file-label" for="close_aggfile">Choose file</label>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label" for="close_nonaggfile">Close Non-AGG File</label>
					<div class="col-sm-12">
						<input type="file" class="custom-file-input" id="close_nonaggfile" name="close_nonaggfile" accept=".csv,.xlsx"  >
						<label class="custom-file-label" for="close_nonaggfile">Choose file</label>
					</div>
				</div>
				<hr/>
				<div class="form-group">
						<button type="submit" class="btn btn-system uploadbtn" >Upload files</button>
				</div>
				
				<?php echo form_close(); ?>
				<!-- End Form -->

                </div>
              </div>

              <!-- Frorm Area end -->
              

            </div>            
          </div>

        </div>
		
		
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->



      <!-- Footer -->
		<?php $this->load->view('admin/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('admin/includes/footer_files');?>
		<script>
			$("document").ready(function () {
				$("#popup").submit(function (e) {
					//disable the submit button
					$(".uploadbtn").attr("disabled", true);
				});
				setTimeout(function () {
					$("div.alert").remove();
				}, 5000); // 5 secs
			});
			
			$(".custom-file-input").on("change", function() {
				  var fileName = $(this).val().split("\\").pop();
				  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
				});
		</script>
      <!-- End of Footer Files -->
	  <!-- Models  -->
		<?php $this->load->view('admin/includes/models');?>
      <!-- End of Models  -->

</body>

</html>



