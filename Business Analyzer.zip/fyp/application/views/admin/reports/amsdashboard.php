<?php $controller_name = $this->router->class;

$method_name = $this->router->method;
$custom_link = $controller_name . '/' . $method_name;
//echo $controller_name; die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('admin/includes/header'); ?>
	<?php $this->load->view('admin/includes/header_files');?>
</head>

<body id="page-top">
  <!-- Page Wrapper -->
  <div id="wrapper">
   <?php $this->load->view('admin/includes/side_bar');?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
        <!-- Topbar -->
			<?php $this->load->view('admin/includes/header_nav');?>
        <!-- End of Topbar -->
        <!-- Begin Page Content -->
		<div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800"> AMS Dashboard Against Different Vendors</h1>
          
          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-12 col-lg-12">

              <!--  Form Area -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Last Data Entry In AMS </h6>
                </div>
                <div class="card-body">
				 <nav>
				  <div class="nav nav-tabs" id="nav-tab" role="tablist">
					<a class="nav-item nav-link active" id="nav-menu1-tab" data-toggle="tab" href="#nav-menu1" role="tab" aria-controls="nav-menu1" aria-selected="true">AMS Campaign</a>
					<a class="nav-item nav-link" id="nav-menu2-tab" data-toggle="tab" href="#nav-menu2" role="tab" aria-controls="nav-menu2" aria-selected="false">AMS Brand</a>
					<a class="nav-item nav-link" id="nav-menu3-tab" data-toggle="tab" href="#nav-menu3" role="tab" aria-controls="nav-menu3" aria-selected="false">AMS Product</a>
				  </div>
				</nav>
				<div class="tab-content" id="nav-tabContent">
				  <div class="tab-pane fade show active" id="nav-menu1" role="tabpanel" aria-labelledby="nav-menu1-tab"><br/>
				   <h3>AMS Campaign</h3>
					<div class="table-responsive">
						<table class="table  " id="dataTable" width="100%" cellspacing="0">
						  <thead>
							 <tr>
								<th>Vendors</th>
								<th>Last Entry in Main</th>
							 </tr>
						  </thead>
						  <tbody>
							<?php 
							foreach ($last_entries_campaigns as $row){ ?>
							<tr>
								<td><?php echo $row->vendor_name .' '. $row->domain ; ?></td>
								<td><?php echo ($row->date != NULL) ? DateConversion($row->date) : 'No Data' ; ?>
							</tr>
							<?php }?>
						  </tbody>
						</table>
					  </div>
				  </div>
				  <div class="tab-pane fade" id="nav-menu2" role="tabpanel" aria-labelledby="nav-menu2-tab"><br/>
				   <h3>AMS Brand</h3>
					<div class="table-responsive">
						<table class="table  " id="dataTable1" width="100%" cellspacing="0">
						  <thead>
							 <tr>
								<th>Vendors</th>
								<th>Last Entry in Main</th>
							 </tr>
						  </thead>
						  <tbody>
							<?php 
							foreach ($last_entries_brands as $row){ ?>
							<tr>
								<td><?php echo $row->vendor_name .' '. $row->domain ; ?></td>
								<td><?php echo ($row->date != NULL) ? DateConversion($row->date) : 'No Data' ; ?>
							</tr>
							<?php }?>
						  </tbody>
						</table>
					  </div>
				  </div>
				  <div class="tab-pane fade" id="nav-menu3" role="tabpanel" aria-labelledby="nav-menu3-tab"><br/>
					 <h3>AMS Product</h3>
					<div class="table-responsive">
						<table class="table  " id="dataTable2" width="100%" cellspacing="0">
						  <thead>
							 <tr>
								<th>Vendors</th>
								<th>Last Entry in Main</th>
							 </tr>
						  </thead>
						  <tbody>
							<?php 
							foreach ($last_entries_products as $row){ ?>
							<tr>
								<td><?php echo $row->vendor_name .' '. $row->domain ; ?></td>
								<td><?php echo ($row->date != NULL) ? DateConversion($row->date) : 'No Data' ; ?>
							</tr>
							<?php }?>
						  </tbody>
						</table>
					  </div>
				  </div>
				</div>
                </div>
              </div>

              <!-- Frorm Area end -->
              

            </div>            
          </div>

        </div>
		
		
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->



      <!-- Footer -->
		<?php $this->load->view('admin/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('admin/includes/footer_files');?>
		
		
      <!-- End of Footer Files -->

	  <!-- Models  -->
		<?php $this->load->view('admin/includes/models');?>
      <!-- End of Models  -->
</body>

</html>



