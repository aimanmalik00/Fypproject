<?php $controller_name = $this->router->class;

$method_name = $this->router->method;
$custom_link = $controller_name . '/' . $method_name;
//echo $controller_name; die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('admin/includes/header'); ?>
	<?php $this->load->view('admin/includes/header_files');?>
</head>

<body id="page-top">
  <!-- Page Wrapper -->
  <div id="wrapper">
   <?php $this->load->view('admin/includes/side_bar');?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
        <!-- Topbar -->
			<?php $this->load->view('admin/includes/header_nav');?>
        <!-- End of Topbar -->
        <!-- Begin Page Content -->
		<div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">  Dropship Dashboard Against Different Vendors</h1>
          
          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-12 col-lg-12">

              <!--  Form Area -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Last Data Entry In Purchase Order Module</h6>
                </div>
                <div class="card-body">
				 <div class="table-responsive">
                <table class="table  " id="dataTable" width="100%" cellspacing="0">
                  <thead>
                     <tr>
						<th>Vendors</th>
						<th>Last Entry in Main</th>
					 </tr>
                  </thead>
                  <tbody>
                    <?php 
					foreach ($last_entries as $row){ ?>
					<tr>
						<td><?php echo $row->vendor_name .' '. $row->domain ; ?></td>
						<td><?php echo ($row->date != NULL) ? DateConversion($row->date) : 'No Data' ; ?>
					</tr>
					<?php }?>
                  </tbody>
                </table>
              </div>
                </div>
              </div>

              <!-- Frorm Area end -->
              

            </div>            
          </div>

        </div>
		
		
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->



      <!-- Footer -->
		<?php $this->load->view('admin/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('admin/includes/footer_files');?>
		
		
      <!-- End of Footer Files -->
	  <!-- Models  -->
		<?php $this->load->view('admin/includes/models');?>
      <!-- End of Models  -->

</body>

</html>



