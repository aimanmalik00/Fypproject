<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php $controller_name = $this->router->class;

$method_name = $this->router->method;
$custom_link = $controller_name . '/' . $method_name;
//echo $controller_name; die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('admin/includes/header'); ?>
	<?php $this->load->view('admin/includes/header_files');?>
</head>

<body id="page-top">
  <!-- Page Wrapper -->
  <div id="wrapper">
   <?php $this->load->view('admin/includes/side_bar');?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
        <!-- Topbar -->
			<?php $this->load->view('admin/includes/header_nav');?>
        <!-- End of Topbar -->
        <!-- Begin Page Content -->
		<div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Password Settings</h1>
          
          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-12 col-lg-12">

              <!--  Form Area -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Change Password</h6>
                </div>
                <div class="card-body">
				<?php echo form_open('admin/admin/change_pass',array('name'=>'password','id'=>'password', 'class'=>'form-horizontal', 'method'=>'post', 'enctype'=>"multipart/form-data" )); ?>
                <?php if($this->session->flashdata('success_msg')) { ?>
                    <div class="alert alert-success">
                        <?php echo $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php } ?>
                <?php if(isset($error_msg)){ ?>
                    <div class="alert alert-danger"><?php echo $error_msg;?></div>
                <?php }?>
				<div class="form-group">
					<label class="control-label" for="old_pass">Old Password</label><span class="text-danger"> * </span>
					<input class="form-control" type="password" id="old_pass" name="old_pass" required>
				</div>
				<div class="form-group">
					<label class="control-label" for="new_pass">New Password</label><span class="text-danger"> * </span>
					<input class="form-control" type="password" id="new_pass" name="new_pass" required>
				</div>
				<div class="form-group">
					<label class="control-label" for="conf_pass">Confirm Password</label><span class="text-danger"> * </span>
					<input class="form-control" type="password" id="conf_pass" name="conf_pass" required>
				</div>
				<hr/>
				<div class="form-group">
						<button type="submit" class="btn btn-system uploadbtn" >Change Password</button>
				</div>
				
				<?php echo form_close(); ?>
				<!-- End Form -->

                </div>
              </div>

              <!-- Frorm Area end -->
              

            </div>            
          </div>

        </div>
		
		
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->



      <!-- Footer -->
		<?php $this->load->view('admin/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('admin/includes/footer_files');?>
		<script>
                var FormValidation = function () {

                    // basic validation
                    var handleValidation1 = function() {
                        // for more info visit the official plugin documentation:
                        // http://docs.jquery.com/Plugins/Validation

                        var form1 = $('#password');
                        var error1 = $('.alert-danger', form1);
                        var success1 = $('.alert-success', form1);

                        form1.validate({
                            errorElement: 'span', //default input error message container
                            errorClass: 'help-block help-block-error', // default input error message class
                            focusInvalid: false, // do not focus the last invalid input
                            ignore: "",  // validate all fields including form hidden input
                            messages: {
                                select_multi: {
                                    maxlength: jQuery.validator.format("Max {0} items allowed for selection"),
                                    minlength: jQuery.validator.format("At least {0} items must be selected")
                                }
                            },
                            rules: {
                                old_pass: {
                                    required: true
                                },
                                new_pass: {
                                    required: true
                                }
                            },

                            invalidHandler: function (event, validator) { //display error alert on form submit
                                success1.hide();
                                error1.show();
                                App.scrollTo(error1, -200);
                            },

                            highlight: function (element) { // hightlight error inputs
                                $(element)
                                    .closest('.form-group').addClass('has-error'); // set error class to the control group
                            },

                            unhighlight: function (element) { // revert the change done by hightlight
                                $(element)
                                    .closest('.form-group').removeClass('has-error'); // set error class to the control group
                            },

                            success: function (label) {
                                label
                                    .closest('.form-group').removeClass('has-error'); // set success class to the control group
                            },

                            submitHandler: function (form) {
                                $("#btn_submit").prop('disabled', true);
                       			form.submit();
                            }
                        });


                    }
                    return {
                        //main function to initiate the module
                        init: function () {

                            handleValidation1();

                        }

                    };

                }();

                jQuery(document).ready(function() {
                    FormValidation.init();
                });
            </script>
      <!-- End of Footer Files -->

	  <!-- Models  -->
		<?php $this->load->view('admin/includes/models');?>
      <!-- End of Models  -->
</body>

</html>



